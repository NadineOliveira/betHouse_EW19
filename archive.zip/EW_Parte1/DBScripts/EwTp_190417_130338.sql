-- Resultado_Evento [rel6]
alter table `resultado`  add column  `evento_oid`  integer;
alter table `resultado`   add index fk_resultado_evento (`evento_oid`), add constraint fk_resultado_evento foreign key (`evento_oid`) references `evento` (`oid`);


