-- Evento [ent1]
alter table `evento`  add column  `estado`  varchar(255);


-- Equipa_Resultado [rel3]
alter table `resultado`  add column  `equipa_oid`  integer;
alter table `resultado`   add index fk_resultado_equipa_2 (`equipa_oid`), add constraint fk_resultado_equipa_2 foreign key (`equipa_oid`) references `equipa` (`oid`);


