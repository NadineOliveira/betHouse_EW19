-- Equipa_Resultado [rel5]
alter table `resultado`  add column  `equipa_oid`  integer;
alter table `resultado`   add index fk_resultado_equipa (`equipa_oid`), add constraint fk_resultado_equipa foreign key (`equipa_oid`) references `equipa` (`oid`);


