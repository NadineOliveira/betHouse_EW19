-- Equipa_Resultado [rel3]
create table `equipa_resultado` (
   `equipa_oid`  integer not null,
   `resultado_oid`  integer not null,
  primary key (`equipa_oid`, `resultado_oid`)
);
alter table `equipa_resultado`   add index fk_equipa_resultado_equipa (`equipa_oid`), add constraint fk_equipa_resultado_equipa foreign key (`equipa_oid`) references `equipa` (`oid`);
alter table `equipa_resultado`   add index fk_equipa_resultado_resultado (`resultado_oid`), add constraint fk_equipa_resultado_resultado foreign key (`resultado_oid`) references `resultado` (`oid`);


