-- Evento [ent1]
alter table `evento`  add column  `estado`  varchar(255);


