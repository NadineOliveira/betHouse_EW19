-- Aposta [ent4]
alter table `aposta`  add column  `resultadoaposta`  varchar(255);


-- Evento_Resultado [rel4]
alter table `evento`  add column  `resultado_oid`  integer;
alter table `evento`   add index fk_evento_resultado (`resultado_oid`), add constraint fk_evento_resultado foreign key (`resultado_oid`) references `resultado` (`oid`);


-- Equipa_Resultado [rel5]
create table `equipa_resultado_2` (
   `equipa_oid`  integer not null,
   `resultado_oid`  integer not null,
  primary key (`equipa_oid`, `resultado_oid`)
);
alter table `equipa_resultado_2`   add index fk_equipa_resultado_2_equipa (`equipa_oid`), add constraint fk_equipa_resultado_2_equipa foreign key (`equipa_oid`) references `equipa` (`oid`);
alter table `equipa_resultado_2`   add index fk_equipa_resultado_2_resultad (`resultado_oid`), add constraint fk_equipa_resultado_2_resultad foreign key (`resultado_oid`) references `resultado` (`oid`);


