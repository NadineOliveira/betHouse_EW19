-- Evento [ent1]
alter table `evento`  add column  `premium`  bit;


