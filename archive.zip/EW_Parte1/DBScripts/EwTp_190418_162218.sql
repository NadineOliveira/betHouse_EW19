-- Evento [ent1]
create table `evento_2` (
   `oid`  integer  not null,
   `odd1`  double precision,
   `oddx`  double precision,
   `odd2`  double precision,
   `data`  varchar(255),
   `estado`  varchar(255),
   `premium`  varchar(255),
   `resultadoevento`  varchar(255),
  primary key (`oid`)
);


