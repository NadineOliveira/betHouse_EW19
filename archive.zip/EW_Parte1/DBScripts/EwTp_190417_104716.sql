-- Group [Group]
create table `group` (
   `oid`  integer  not null,
   `groupname`  varchar(255),
  primary key (`oid`)
);


-- Module [Module]
create table `module` (
   `oid`  integer  not null,
   `moduleid`  varchar(255),
   `modulename`  varchar(255),
  primary key (`oid`)
);


-- User [User]
create table `user` (
   `oid`  integer  not null,
   `username`  varchar(255),
   `password`  varchar(255),
   `email`  varchar(255),
   `saldo`  double precision,
  primary key (`oid`)
);


-- Evento [ent1]
create table `evento` (
   `oid`  integer  not null,
   `odd1`  double precision,
   `oddx`  double precision,
   `odd2`  double precision,
   `data`  date,
   `estado`  varchar(255),
  primary key (`oid`)
);


-- Equipa [ent2]
create table `equipa` (
   `oid`  integer  not null,
   `nome`  varchar(255),
  primary key (`oid`)
);


-- Resultado [ent3]
create table `resultado` (
   `oid`  integer  not null,
   `resultado`  varchar(255),
  primary key (`oid`)
);


-- Aposta [ent4]
create table `aposta` (
   `oid`  integer  not null,
   `valor`  double precision,
   `data`  date,
   `resultadoaposta`  varchar(255),
  primary key (`oid`)
);


