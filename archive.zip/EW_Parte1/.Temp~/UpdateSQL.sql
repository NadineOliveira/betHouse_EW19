-- User [User]
alter table `user`  add column  `saldo`  double precision;


