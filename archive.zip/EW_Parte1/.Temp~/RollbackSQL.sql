-- Aposta_Evento [rel2]
alter table `aposta_evento`   drop foreign key `fk_aposta_evento_evento`;
alter table `aposta_evento`   drop foreign key `fk_aposta_evento_aposta`;
drop table `aposta_evento`;
-- Equipa_Evento [rel1]
alter table `equipa_evento`   drop foreign key `fk_equipa_evento_evento`;
alter table `equipa_evento`   drop foreign key `fk_equipa_evento_equipa`;
drop table `equipa_evento`;
-- User_Group [User2Group_Group2User]
alter table `user_group`   drop foreign key `fk_user_group_group`;
alter table `user_group`   drop foreign key `fk_user_group_user`;
drop table `user_group`;
-- User_DefaultGroup [User2DefaultGroup_DefaultGroup2User]
alter table `user`   drop foreign key `fk_user_group`;
alter table `user`  drop column  `group_oid`;
-- Group_Module [Group2Module_Module2Group]
alter table `group_module`   drop foreign key `fk_group_module_module`;
alter table `group_module`   drop foreign key `fk_group_module_group`;
drop table `group_module`;
-- Group_DefaultModule [Group2DefaultModule_DefaultModule2Group]
alter table `group`   drop foreign key `fk_group_module`;
alter table `group`  drop column  `module_oid`;
-- Aposta [ent4]
drop table `aposta`;
-- Resultado [ent3]
drop table `resultado`;
-- Equipa [ent2]
drop table `equipa`;
-- Evento [ent1]
drop table `evento`;
-- User [User]
drop table `user`;
-- Module [Module]
drop table `module`;
-- Group [Group]
drop table `group`;
