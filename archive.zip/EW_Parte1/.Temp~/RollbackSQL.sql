-- Evento [ent1]
alter table `evento`   drop column  `premium`;
